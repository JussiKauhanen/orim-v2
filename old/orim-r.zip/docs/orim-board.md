---
name: orim-board
description: Read, create and edit orim boards: Mermaid flowcharts with Azure, Power Platform and Dynamics 365 icons, sticky notes and saved positions in %% @pos lines. Use when asked for an orim board or given Mermaid code with %% @pos lines.
---

# orim board format

orim draws a Mermaid flowchart as a whiteboard. Reply with the complete board in one ```mermaid block (no fragments or diffs), then at most a short note. Change only what was asked; keep the title, ids, styles and every %% line of the rest. Flowcharts only.

## Syntax

```
---
title: Board title
---
flowchart LR
  user@{ icon: "azure:users", label: "Customer" }
  subgraph rg [Resource group]
    api@{ icon: "azure:function-apps", label: "Orders API" }
    db[(Orders DB)]
  end
  note["Check retention"]:::sticky
  user --> api
  api -->|writes| db
  style note fill:#ffcee0
```

- Shapes: `id[Rect]` `id(Rounded)` `id([Pill])` `id[(Database)]` `id((Circle))` `id{Decision}` `id{{Hex}}` `id[/Lean/]` `id[[Subroutine]]` `id["Note"]:::sticky` `id@{ shape: text, label: "Plain text" }` `id@{ icon: "pack:id", label: "Name" }`
- Edges: `-->` arrow, `---` line, `-.->` dotted, `==>` thick, `<-->` both ways, `--o` `--x` circle or cross end, `-->|label|`. Chains `a --> b --> c` and `a & b --> c` work. Frames connect by id.
- Style: `style id fill:#hex,stroke:#hex,color:#hex,font-size:18px,font-weight:bold,font-style:italic,background:#hex`; `linkStyle 0 stroke:#hex,stroke-width:3px`.
- Connector style for the whole board is Mermaid's front matter setting `config: flowchart: curve:` with `basis` (curved), `linear` (straight) or `step` (elbow). Keep it if present.
- Direction: LR, RL, TB or BT. Ids: camelCase letters and digits, unique, not a keyword (end, graph, subgraph, style, class, direction). Declare a node once with its label, then use its id.
- Labels: `<br>` for a line break, `#quot;` for a quote; quote labels with brackets: `id["Cache (Redis)"]`.
- A node belongs to the frame (subgraph) it is declared in. Frames can nest.
- linkStyle numbers edges from 0 in order; renumber if you add or remove edges above it.
- Sticky colors: #fff9b1 #f5d128 #ff9d48 #d5f692 #c9df56 #93d275 #67c6c0 #a6ccf5 #6cd8fa #9ea9ff. Keep any `classDef sticky` line.

## %% lines (canvas data, after the code)

- `%% @pos id x y [w h]` is where the user placed a node or frame. Keep it for every item you keep; rename or delete it with the item. New nodes need none: orim places them next to what they connect to. If you rebuild most of the board, delete all @pos and @route lines and orim lays it out again.
- `%% @route i kind [from to]` pins edge number i to sides of its shapes (t r b l, - for automatic); renumber it if you add or remove edges before it.
- Copy `%% @route`, `@arrow`, `@ink`, `@image` and `@comment` lines unchanged. `@comment` lines are the user's review comments; read them, they may say what to change.

## Icons

Write `pack:id`. If nothing fits, use a plain node.
pp: ai-builder copilot-studio dataverse power-apps power-automate power-bi power-fx power-pages power-platform
d365: business-central commerce connected-store core-hr customer-insights customer-service customer-service-insights customer-voice dynamics-365 field-service finance finance-operations fraud-protection import-tool intelligent-order-management layout mr-portal marketing product-visualize product-insights project-service-automation project-timesheet remote-assist return-to-school return-to-work scm-warehousing sales sales-insights supply-chain-management sustainability-calculator talent-attract talent-onboard voice-assistant

azure:
- AI + Machine Learning: ai-foundry ai-studio anomaly-detector azure-ai-foundry-iq azure-applied-ai-services azure-experimentation-studio azure-machine-learning azure-object-understanding azure-openai batch-ai bonsai bot-services cognitive-search cognitive-services cognitive-services-decisions computer-vision content-moderators content-safety custom-vision face-apis form-recognizers foundry-agent-service foundry-application foundry-control-plane foundry-labs foundry-local foundry-models foundry-project frd-qa genomics genomics-accounts immersive-readers language language-understanding machine-learning machine-learning-studio-classic-web-services machine-learning-studio-web-service-plans machine-learning-studio-workspaces metrics-advisor personalizers planetary-computer-pro qna-makers serverless-search speech-services translator-text
- Analytics: analysis-services azure-data-explorer-clusters azure-databricks azure-synapse-analytics azure-workbooks data-factories data-lake-analytics data-lake-store-gen1 endpoint-analytics event-hub-clusters event-hubs hd-insight-clusters log-analytics-workspaces power-bi-embedded power-platform private-link-services stream-analytics-jobs
- App Services: app-service-certificates app-service-domains app-service-environments app-service-plans app-services cdn-profiles notification-hubs
- Azure Ecosystem: applens azure-hybrid-center collaborative-service
- Blockchain: abs-member azure-blockchain-service azure-token-service blockchain-applications consortium outbound-connection
- Compute: aks-automatic application-group automanaged-vm availability-sets azure-compute-galleries azure-linux azure-spring-apps batch-accounts cloud-services-classic compute-fleet container-instances container-services-deprecated disk-encryption-sets disks disks-classic disks-snapshots function-apps host-groups host-pools hosts image-definitions image-templates image-versions images kubernetes-services maintenance-configuration managed-service-fabric mesh-applications os-images-classic restore-points restore-points-collections scheduled-actions service-fabric-clusters shared-image-galleries stage-maps virtual-machine virtual-machines-classic vm-images-classic vm-scale-sets workspaces
- Containers: aks-network-policy azure-container-storage azure-red-hat-openshift container-registries kubernetes-hub service-groups
- Databases: azure-cosmos-db azure-database-mariadb-server azure-database-migration-services azure-database-mysql-server azure-database-postgresql-server azure-database-postgresql-server-group azure-documentdb azure-managed-redis azure-sql azure-sql-edge azure-sql-server-stretch-databases azure-sql-vm cache-redis elastic-job-agents instance-pools managed-database oracle-database sql-data-warehouses sql-database sql-database-fleet-manager sql-elastic-pools sql-managed-instance sql-server sql-server-registries ssis-lift-and-shift-ir virtual-clusters
- Developer Tools: azure-app-testing
- DevOps: api-connections api-management-services application-insights azure-devops change-analysis cloudtest code-optimization devops-starter devtest-labs lab-accounts lab-services load-testing managed-devops-pools workspace-gateway
- General: all-resources backlog biz-talk blob-block blob-page branch browser bug builds cache code commit controls controls-horizontal cost-alerts cost-analysis cost-budgets cost-management cost-management-and-billing counter cubes dashboard dev-console download error extensions feature-previews file files folder-blank folder-website free-services ftp gear globe-error globe-success globe-warning guide heart help-and-support image information input-output journey-hub launch-portal learn load-test location log-streaming management-groups management-portal marketplace marketplace-management media media-file mobile mobile-engagement module power power-up powershell preview-features process-explorer production-ready-database quickstart-center recent region-management reservations resource-explorer resource-group-list resource-groups resource-linked scheduler search search-grid server-farm service-health ssd storage-azure-files storage-container storage-queue subscriptions table tag tags templates tfs-vc-repository toolbox troubleshoot versions web-slots web-test website-power website-staging workbooks workflow
- Hybrid + Multicloud: ai-at-edge arc-kubernetes azure-local azure-monitor-pipeline azure-operator-5g-core azure-operator-insights azure-operator-nexus azure-operator-service-manager azure-programmable-connectivity edge-storage-accelerator workload-orchestration
- Identity: active-directory-connect-health administrative-units api-proxy app-registrations azure-ad-b2c azure-information-protection enterprise-applications entra-connect entra-connect-health entra-connect-sync entra-domain-services entra-global-secure-access entra-id-protection entra-identity-custom-roles entra-identity-licenses entra-identity-roles-and-administrators entra-internet-access entra-managed-identities entra-private-access entra-privleged-identity-management entra-verified-id external-id external-id-modified external-identities groups identity-governance managed-identities entra-id multi-factor-authentication multi-tenancy security tenant-properties user-settings user-subscriptions users verifiable-credentials verification-as-a-service
- Integration: app-configuration azure-api-for-fhir azure-data-catalog azure-databox-gateway azure-service-bus business-process-tracking event-grid-domains event-grid-subscriptions event-grid-topics integration-accounts integration-environments integration-service-environments logic-apps logic-apps-custom-connector logic-apps-template partner-namespace partner-registration partner-topic pubsub relays sendgrid-accounts software-as-a-service storsimple-device-managers system-topic
- Intune: client-apps device-compliance device-configuration device-enrollment device-security-apple device-security-google device-security-windows devices ebooks engage-center-connect exchange-access intune intune-app-protection intune-for-education mindaro security-baselines software-updates tenant-status
- IoT: azure-iot-operations azure-maps-accounts azure-stack-hci-sizer device-provisioning-services digital-twins hybrid-connectivity-hub industrial-iot iot-central-applications iot-edge iot-hub notification-hub-namespaces stack-hci-premium time-series-data-sets time-series-insights-access-policies time-series-insights-environments time-series-insights-event-sources windows10-core-services
- Management + Governance: activity-log advisor alerts arc-machines automation-accounts azure-arc azure-lighthouse blueprints compliance customer-lockbox-for-microsoft-azure diagnostics-settings education intune-trends machinesazurearc managed-applications-center managed-desktop metrics monitor my-customers operation-log-classic policy recovery-services-vaults resource-graph-explorer resources-provider scheduler-job-collections service-catalog-mad service-group-relationships service-providers solutions universal-print user-privacy
- Menu: keys
- Migrate: azure-migrate data-box
- Mixed Reality: remote-rendering spatial-anchor-accounts
- Monitor: auto-scale azure-monitors-for-sap-solutions network-watcher
- Networking: application-gateway-containers application-gateways atm-multistack azure-communications-gateway azure-firewall-manager azure-firewall-policy bastions connected-cache connections ddos-protection-plans dns-multistack dns-private-resolver dns-security-policy dns-zones edge-actions expressroute-circuits firewalls front-door-and-cdn-profiles ip-address-manager ip-groups load-balancer-hub load-balancers local-network-gateways nat network-foundation-hub network-interfaces network-security-groups network-security-hub on-premises-data-gateways private-link private-link-service proximity-placement-groups public-ip-addresses public-ip-addresses-classic public-ip-prefixes reserved-ip-addresses-classic resource-management-private-link route-filters route-tables service-endpoint-policies spot-vm spot-vmss subnet traffic-manager-profiles virtual-network-gateways virtual-networks virtual-networks-classic virtual-router virtual-wan-hub virtual-wans vnet-appliance vpnclientwindows web-application-firewall-policies-waf
- New Icons: agentic-web-apps ai-gateway azure-access-point azure-data-sharing azure-data-transfer ddos-custom-policy disconnected-operations landing-zone resiliency toolchain-orchestrator
- Other: aks-istio app-compliance-automation aquila arc-data-services arc-postgresql arc-sql-managed-instance arc-sql-server avs-vm azure-a azure-backup-center azure-center-for-sap azure-chaos-studio azure-cloud-shell azure-communication-services azure-consumption-commitment azure-deployment-environments azure-dev-tunnels azure-edge-hardware-center azure-enclaves azure-hpc-workbenches azure-load-testing azure-managed-grafana azure-monitor-dashboard azure-network-function-manager azure-network-function-manager-functions azure-orbital azure-quotas azure-sphere azure-storage-mover azure-support-center-blue azure-sustainability azure-video-indexer azure-virtual-desktop azure-vmware-solution azureattestation azurite backup-vault bare-metal-infrastructure breeze capacity-reservation-groups central-service-instance-for-sap ceres cloud-services-extended-support community-images compliance-center confidential-ledgers connected-vehicle-platform container-apps-environments cost-export custom-ip-prefix dashboard-hub data-collection-rules database-instance-for-sap dedicated-hsm defender-cm-local-manager defender-dcs-controller defender-distributer-control-system defender-engineering-station defender-external-management defender-freezer-monitor defender-historian defender-hmi defender-industrial-packaging-system defender-industrial-printer defender-industrial-robot defender-industrial-scale-system defender-marquee defender-meter defender-plc defender-pneumatic-device defender-programable-board defender-relay defender-robot-controller defender-rtu defender-sensor defender-slot defender-web-guiding-system device-update-iot-hub disk-pool edge-management elastic-san exchange-on-premises-access express-route-traffic-collector expressroute-direct fhir-service fiji hdi-aks-cluster icm-troubleshooting internet-analyzer-profiles kubernetes-fleet-manager log-analytics-query-pack managed-instance-apache-cassandra medtech-service microsoft-dev-box microsoft-discovery mission-landing-zone mobile-networks modular-data-center monitor-health-models network-managers network-security-perimeters open-supply-chain-platform osconfig peering-service peerings private-endpoints promethus reserved-capacity resource-guard resource-mover rtos savings-plans scvmm-management-servers sonic-dash ssh-keys storage-functions targets-management template-specs test-base update-management-center video-analyzers virtual-instance-for-sap virtual-visits-builder vm-app-definitions vm-app-versions vm-image-version wac wac-installer web-app-database web-jobs windows-notification-services worker-container-app
- Security: application-security-groups azure-sentinel conditional-access detonation entra-identity-risky-signins entra-identity-risky-users extendedsecurityupdates identity-secure-score key-vaults microsoft-defender-easm microsoft-defender-for-cloud microsoft-defender-for-iot multifactor-authentication
- Storage: azure-fileshares azure-hcp-cache azure-netapp-files data-lake-storage-gen1 data-share-invitations data-shares data-virtualization import-export-jobs managed-file-shares storage-accounts storage-accounts-classic storage-actions storage-explorer storage-hubs storage-sync-services storsimple-data-managers
- Web: api-center app-space app-space-component azure-media-service signalr static-apps
